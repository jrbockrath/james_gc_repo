import os
from flask import Flask, request, jsonify, render_template, redirect, url_for
from vertexai.generative_models import GenerativeModel, Part

# Initialize Flask app with the correct template folder relative to the working directory
app = Flask(__name__, template_folder='flask_templates')

# Configuration for Vertex AI
MODEL_NAME = "gemini-1.5-pro"

# Initialize the generative model
model = GenerativeModel(MODEL_NAME)

# Route to display the main interface
@app.route('/', methods=['GET', 'POST'])
def home():
    try:
        if request.method == 'POST':
            model_name = request.form['model']
            user_input = request.form['user_input']
            action = request.form['action']
            return redirect(url_for('process_request', model_name=model_name, user_input=user_input, action=action))
        
        # Debug logs
        print("Serving index.html from:", app.template_folder)
        return render_template('index.html', models={"gemini-1.5-pro": "Gemini 1.5 Pro"})
    except Exception as e:
        # Log the error for debugging purposes
        print(f"Error in home route: {e}")
        return jsonify({"error": str(e)}), 500

# Route to process requests and interact with the Vertex AI model
@app.route('/process_request')
def process_request():
    model_name = request.args.get('model_name', MODEL_NAME)
    user_input = request.args.get('user_input')
    action = request.args.get('action')

    try:
        if action == "summarize_and_generate_image":
            # Generate summary
            summary = model.generate_content(Part.from_text(user_input))
            
            # Use another model for image generation based on the summary
            image_model = GenerativeModel("image-generation-2.0")
            image_result = image_model.generate_content(Part.from_text(summary))
            
            return render_template('result.html', summary=summary, image=image_result)

        # Default action: generate text content
        generated_content = model.generate_content(Part.from_text(user_input))
        return render_template('result.html', generated_content=generated_content)
    
    except Exception as e:
        # Log the error for debugging purposes
        print(f"Error in process_request route: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    # Log the current working directory and template folder
    print("Current Working Directory:", os.getcwd())
    print("Flask Template Folder:", app.template_folder)
    app.run(host='0.0.0.0', port=80, debug=True)
