#!/bin/bash

# Set environment variables
export PROJECT_ID="heroic-oven-430715-i1"
export CLUSTER_NAME="python-k8s-demo-cluster-v2"
export ZONE="us-central1-a"
export REGION="us-central1"
export EMAIL="james@swipeleft.ai"
export LOCATION="us-central1"
export MODEL_NAME="gemini-1.5-pro"
export MODEL_VERSION="001"

# Set default app parameters
DEFAULT_APP_NAME="app1"
DEFAULT_IMAGE_TAG="v1"

# Set the active GCP project
gcloud config set project ${PROJECT_ID}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if necessary commands exist
if ! command_exists gcloud || ! command_exists kubectl || ! command_exists helm || ! command_exists openssl; then
    echo "Error: gcloud, kubectl, helm, and openssl are required. Please install them and try again."
    exit 1
fi

# Check if the cluster exists and create it if necessary
if ! gcloud container clusters describe ${CLUSTER_NAME} --zone=${ZONE} &>/dev/null; then
    echo "Cluster ${CLUSTER_NAME} does not exist. Creating it now..."
    gcloud container clusters create ${CLUSTER_NAME} \
        --project=${PROJECT_ID} \
        --zone=${ZONE} \
        --num-nodes=3 \
        --machine-type=e2-medium
    echo "Cluster ${CLUSTER_NAME} has been created."
else
    echo "Cluster ${CLUSTER_NAME} already exists."
fi

# Connect to the existing cluster
echo "Connecting to the existing cluster ${CLUSTER_NAME}..."
gcloud container clusters get-credentials ${CLUSTER_NAME} --zone=${ZONE}

# Deploy the application using Helm
deploy_app() {
    local APP_NAME=$1
    local IMAGE_TAG=$2
    echo "Deploying ${APP_NAME} with image tag ${IMAGE_TAG}..."

    helm upgrade --install ${APP_NAME} ./apps/${APP_NAME}/helm \
        --set image.tag=${IMAGE_TAG} \
        --set serviceAccount.name=${SERVICE_ACCOUNT} \
        --set projectId=${PROJECT_ID} \
        --set googleApplicationCredentials=${GOOGLE_APPLICATION_CREDENTIALS} \
        --namespace ${APP_NAME}-namespace \
        --create-namespace

    echo "Application ${APP_NAME} deployed successfully."
}

# Deploy only app1
deploy_app "app1" "v1"

# Function to recreate service for an app
recreate_service() {
    local APP_NAME=$1
    local NAMESPACE="${APP_NAME}-namespace"
    
    echo "Recreating service for ${APP_NAME}..."
    kubectl delete svc ${APP_NAME} -n ${NAMESPACE}
    kubectl expose deployment ${APP_NAME} --type=LoadBalancer --name=${APP_NAME} -n ${NAMESPACE}

    echo "Waiting for service ${APP_NAME} to be ready..."
    while true; do
        ENDPOINTS=$(kubectl get endpoints ${APP_NAME} -n ${NAMESPACE} -o jsonpath='{.subsets[0].addresses}' 2>/dev/null)
        if [ -n "${ENDPOINTS}" ]; then
            echo "Service ${APP_NAME} is ready with endpoints: ${ENDPOINTS}"
            break
        else
            echo "Waiting for service ${APP_NAME} to become ready..."
            sleep 10
        fi
    done

    echo "Checking for external IP for ${APP_NAME}..."
    for i in {1..30}; do
        EXTERNAL_IP=$(kubectl get svc ${APP_NAME} -n ${NAMESPACE} -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null)
        if [ -n "${EXTERNAL_IP}" ]; then
            echo "Service ${APP_NAME} is accessible via external IP: ${EXTERNAL_IP}"
            break
        else
            echo "Waiting for external IP for ${APP_NAME}... (Attempt $i)"
            sleep 10
        fi
    done

    if [ -z "${EXTERNAL_IP}" ]; then
        echo "Error: Service ${APP_NAME} did not receive an external IP after 5 minutes."
        exit 1
    fi
}

# Define the list of apps to process; currently only app1 is included
APPS=("app1")

# Loop through the list of apps and recreate services; currently only processes app1
for APP_NAME in "${APPS[@]}"; do
    recreate_service "${APP_NAME}"
done

# Final message
echo "Application app1 and associated services have been successfully deployed and are operational."
